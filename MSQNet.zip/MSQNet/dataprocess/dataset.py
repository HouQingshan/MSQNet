import os
import pandas as pd

import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
import numpy as np
from skimage import color
import cv2
cv2.setNumThreads(1)
import random


class MyDataset(Dataset):

    def __init__(self, args, mode='train'):
        
        self.mode = mode
        
        self.train_csv_path = args.train_csv_path
        self.val_csv_path = args.val_csv_path
        self.test_csv_path = args.test_csv_path
        self.gt_image_path = args.gt_image_path
        self.de_image_path = args.de_image_path
        self.image_mask = args.image_mask

        
        train_data = pd.read_csv(self.train_csv_path)
        val_data = pd.read_csv(self.val_csv_path)
        test_data = pd.read_csv(self.test_csv_path)

        if mode == 'train':    
            self.train_image_name = [str(name)+'.png' for name in train_data['image']]
        elif mode == 'val':
            self.test_image_name = [str(name)+'.png' for name in val_data['image']]
        elif mode == 'test':
            self.test_image_name = [str(name)+'.png' for name in test_data['image']]


    def __len__(self):
        if self.mode=='train':
            return len(self.train_image_name)
        else:
            return len(self.test_image_name)

    def __getitem__(self, idx):
        
        #get data
        if self.mode == 'train':
            image_name = self.train_image_name[idx]
            gt_image_bgr = cv2.imread(os.path.join(self.gt_image_path, image_name))
            gt_image_rgb = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2RGB)
            gt_image_hsv = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2HSV)
            gt_image_lab = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2LAB)
            gt_image_vab = np.concatenate((gt_image_hsv[:,:,2].reshape(512, 512, 1), gt_image_lab[:,:,1:]), axis=2)

            de_image_bgr = cv2.imread(os.path.join(self.de_image_path, image_name))
            de_image_rgb = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2RGB)
            de_image_hsv = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2HSV)
            de_image_lab = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2LAB)
            de_image_vab = np.concatenate((de_image_hsv[:,:,2].reshape(512, 512, 1), de_image_lab[:,:,1:]), axis=2)

            if self.image_mask != 'None':
                image_mask_bgr = cv2.imread(os.path.join(self.image_mask, image_name))
                image_mask = cv2.cvtColor(image_mask_bgr, cv2.COLOR_BGR2RGB)

        else:
            image_name = self.test_image_name[idx]
            gt_image_bgr = cv2.imread(os.path.join(self.gt_image_path, image_name))
            gt_image_rgb = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2RGB)
            gt_image_hsv = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2HSV)
            gt_image_lab = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2LAB)
            gt_image_vab = np.concatenate((gt_image_hsv[:,:,2].reshape(512, 512, 1), gt_image_lab[:,:,1:]), axis=2)

            de_image_bgr = cv2.imread(os.path.join(self.de_image_path, image_name))
            de_image_rgb = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2RGB)
            de_image_hsv = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2HSV)
            de_image_lab = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2LAB)
            de_image_vab = np.concatenate((de_image_hsv[:,:,2].reshape(512, 512, 1), de_image_lab[:,:,1:]), axis=2)

            if self.image_mask != 'None':
                image_mask_bgr = cv2.imread(os.path.join(self.image_mask, image_name))
                image_mask = cv2.cvtColor(image_mask_bgr, cv2.COLOR_BGR2RGB)

        transform = transforms.Compose([
                transforms.ToPILImage(),
                # transforms.RandomRotation(90),
                # transforms.RandomCrop((448, 448)),
                transforms.Resize((512, 512)),
                transforms.RandomHorizontalFlip(),
                transforms.RandomVerticalFlip(),
                transforms.ToTensor(),
                # ImageNet
                # transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                # EyeQ Nerve
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
                # heart CT
                # transforms.Normalize([0.03557858616113663, 0.03966348245739937, 0.060139432549476624], [0.0829882025718689, 0.0926036387681961, 0.1139526516199112])
                # ISIC
                # transforms.Normalize([0.3329312801361084, 0.22033365070819855, 0.2032770961523056], [0.1005207896232605, 0.11310195922851562, 0.12081697583198547])
                # X-ray
                # transforms.Normalize([0.23972900211811066, 0.23972900211811066, 0.23972900211811066],  [0.16708318889141083, 0.16708318889141083, 0.16708318889141083])
            ])

        transform_valid = transforms.Compose([
                transforms.ToPILImage(),
                transforms.Resize((512, 512)),
                transforms.ToTensor(),
                # ImageNet
                # transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                # EyeQ Nerve
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
                # heart CT
                # transforms.Normalize([0.03557858616113663, 0.03966348245739937, 0.060139432549476624], [0.0829882025718689, 0.0926036387681961, 0.1139526516199112])
                # ISIC
                # transforms.Normalize([0.3329312801361084, 0.22033365070819855, 0.2032770961523056], [0.1005207896232605, 0.11310195922851562, 0.12081697583198547])
                # X-ray
                # transforms.Normalize([0.23972900211811066, 0.23972900211811066, 0.23972900211811066],  [0.16708318889141083, 0.16708318889141083, 0.16708318889141083])
            ])

        transform_mask = transforms.Compose([
                transforms.ToPILImage(),
                transforms.ToTensor(),
            ])
        
        if self.mode == 'train':
            seed = random.randint(0, 2 ** 32)
            torch.manual_seed(seed)
            random.seed(seed)
            gt_image_rgb = transform(gt_image_rgb)

            torch.manual_seed(seed)
            random.seed(seed)
            de_image_rgb = transform(de_image_rgb)

            torch.manual_seed(seed)
            random.seed(seed)
            gt_image_vab = transform(gt_image_vab)

            torch.manual_seed(seed)
            random.seed(seed)
            de_image_vab = transform(de_image_vab)

            torch.manual_seed(seed)
            random.seed(seed)
            if self.image_mask != 'None':
                image_mask = transform(image_mask)
            else:
                image_mask = 'None'
        else:
            gt_image_rgb = transform_valid(gt_image_rgb)
            de_image_rgb = transform_valid(de_image_rgb)
            gt_image_vab = transform_valid(gt_image_vab)
            de_image_vab = transform_valid(de_image_vab)
            if self.image_mask != 'None':
                image_mask = transform_mask(image_mask)
            else:
                image_mask = 'None'

        # image_mask = self.transform_for_image_mask(image_mask)


        return gt_image_rgb, de_image_rgb, gt_image_vab, de_image_vab, image_mask, image_name

    def transform_for_image_mask(self, image_mask):
        image_mask = np.array(image_mask, np.float32).transpose(2, 0, 1) / 255.0
        return torch.from_numpy(image_mask).float()

# class MyDataset(Dataset):

#     def __init__(self, args, mode='train'):
        
#         self.mode = mode
        
#         self.data_csv_path = args.data_csv_path
#         self.gt_image_path = args.gt_image_path
#         self.de_image_path = args.de_image_path
#         self.lesion_image_path = args.lesion_image_path
#         self.image_mask = args.image_mask
        
#         data = pd.read_csv(self.data_csv_path)
        
#         self.image_name = [name+'.png' for name in data['image']]
#         self.lesion_image_name = [name+'-mask.jpg' for name in data['image']]
#         self.class_label = data['Retinopathy_grade'].tolist()

#         self.train_image_name = self.image_name[0:int(len(self.image_name)*0.7)]
#         self.train_lesion_image_name = self.lesion_image_name[0:int(len(self.lesion_image_name)*0.7)]
#         self.train_class_label = self.class_label[0:int(len(self.class_label)*0.7)]
        
#         self.test_image_name = self.image_name[int(len(self.image_name)*0.7):]
#         self.test_lesion_image_name = self.lesion_image_name[int(len(self.lesion_image_name)*0.7):]
#         self.test_class_label = self.class_label[int(len(self.class_label)*0.7):]

#     def __len__(self):
#         if self.mode=='train':
#             return len(self.train_image_name)
#         else:
#             return len(self.test_image_name)

#     def __getitem__(self, idx):
        
#         #get data
#         if self.mode == 'train':
#             image_name = self.train_image_name[idx]
#             gt_image_bgr = cv2.imread(os.path.join(self.gt_image_path, image_name))
#             gt_image_rgb = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2RGB)
#             gt_image_hsv = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2HSV)
#             gt_image_lab = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2LAB)
#             gt_image_vab = np.concatenate((gt_image_hsv[:,:,2].reshape(512, 512, 1), gt_image_lab[:,:,1:]), axis=2)

#             de_image_bgr = cv2.imread(os.path.join(self.de_image_path, image_name))
#             de_image_rgb = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2RGB)
#             de_image_hsv = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2HSV)
#             de_image_lab = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2LAB)
#             de_image_vab = np.concatenate((de_image_hsv[:,:,2].reshape(512, 512, 1), de_image_lab[:,:,1:]), axis=2)

#             lesion_image_bgr = cv2.imread(os.path.join(self.lesion_image_path, self.train_lesion_image_name[idx]))
#             lesion_image = cv2.cvtColor(lesion_image_bgr, cv2.COLOR_BGR2RGB)

#             image_mask_bgr = cv2.imread(os.path.join(self.image_mask, image_name))
#             image_mask = cv2.cvtColor(image_mask_bgr, cv2.COLOR_BGR2RGB)

#             label = torch.zeros(4)
#             label[self.train_class_label[idx]] = 1

#         else:
#             image_name = self.test_image_name[idx]
#             gt_image_bgr = cv2.imread(os.path.join(self.gt_image_path, image_name))
#             gt_image_rgb = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2RGB)
#             gt_image_hsv = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2HSV)
#             gt_image_lab = cv2.cvtColor(gt_image_bgr, cv2.COLOR_BGR2LAB)
#             gt_image_vab = np.concatenate((gt_image_hsv[:,:,2].reshape(512, 512, 1), gt_image_lab[:,:,1:]), axis=2)

#             de_image_bgr = cv2.imread(os.path.join(self.de_image_path, image_name))
#             de_image_rgb = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2RGB)
#             de_image_hsv = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2HSV)
#             de_image_lab = cv2.cvtColor(de_image_bgr, cv2.COLOR_BGR2LAB)
#             de_image_vab = np.concatenate((de_image_hsv[:,:,2].reshape(512, 512, 1), de_image_lab[:,:,1:]), axis=2)

#             lesion_image_bgr = cv2.imread(os.path.join(self.lesion_image_path, self.test_lesion_image_name[idx]))
#             lesion_image = cv2.cvtColor(lesion_image_bgr, cv2.COLOR_BGR2RGB)
            
#             image_mask_bgr = cv2.imread(os.path.join(self.image_mask, image_name))
#             image_mask = cv2.cvtColor(image_mask_bgr, cv2.COLOR_BGR2RGB)

#             label = torch.zeros(4).float()
#             label[self.test_class_label[idx]] = 1.0
        
#         transform = transforms.Compose([
#                 transforms.ToPILImage(),
#                 transforms.ToTensor(),
#                 transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
#             ])
        

#         gt_image_rgb = transform(gt_image_rgb)
#         gt_image_vab = transform(gt_image_vab)

#         de_image_rgb = transform(de_image_rgb)
#         de_image_vab = transform(de_image_vab)

#         lesion_image = self.transform_for_lesion_mask(lesion_image)
#         image_mask = self.transform_for_image_mask(image_mask)

#         return gt_image_rgb, gt_image_vab, de_image_rgb, de_image_vab, lesion_image, image_mask, label, image_name

#     def transform_for_lesion_mask(self, lesion_mask):
#         lesion_mask = np.array(lesion_mask, np.float32).transpose(2, 0, 1) / 255.0
#         lesion_mask[lesion_mask >= 0.5] = 1
#         lesion_mask[lesion_mask <= 0.5] = 0
#         return torch.from_numpy(lesion_mask).float()

#     def transform_for_image_mask(self, image_mask):
#         image_mask = np.array(image_mask, np.float32).transpose(2, 0, 1) / 255.0
#         return torch.from_numpy(image_mask).float()