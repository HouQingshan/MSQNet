import torch
import torch.nn as nn
from MSQNet_Parms_Flops.model.MSQ import MSQNet
from model.MCL import MCLNet

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.MSQNet = MSQNet()
        self.MCLNet = MCLNet()
        
    def forward(self, RGB_img, VAB_img):
        RGB_en, VAB_en = self.MSQNet(RGB_img, VAB_img)
        classify_res, seg_res = self.MCLNet(RGB_en)
        
        return RGB_en, VAB_en, classify_res, seg_res