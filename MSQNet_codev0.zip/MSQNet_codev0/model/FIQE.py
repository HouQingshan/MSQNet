import torch
import torch.nn as nn
import torchvision
from torchvision.models import resnet50
from . import common
from model.utils import Positonal_Encoding
from model.utils import UpSampeBlock
from model.utils import make_norm, make_paddding, ResnetBlock

from torchvision import models
import torch.nn.functional as F

from functools import partial

class MST(nn.Module):
    def __init__(self):
        super(MST, self).__init__()
        # self.pe = None
        # self.layer_norm = None
        
    def forward(self, RGB_feature, VAB_feature):
        batch_size = RGB_feature.shape[0]
        Channel_num = RGB_feature.shape[1]
        H = RGB_feature.shape[2]
        W = RGB_feature.shape[3]

        pe = Positonal_Encoding(Channel_num, H*W).cuda()
        layer_norm = nn.LayerNorm([H*W, Channel_num]).cuda()
        
        Q = pe(RGB_feature.reshape(batch_size, -1, Channel_num))
        K = pe(VAB_feature.reshape(batch_size, -1, Channel_num))
        V = pe(VAB_feature.reshape(batch_size, -1, Channel_num))
        
        Q_layernorm = layer_norm(Q).reshape(batch_size, Channel_num, H, W)
        K_layernorm = layer_norm(K).reshape(batch_size, Channel_num, H, W)
        V_layernorm = layer_norm(V).reshape(batch_size, Channel_num, H, W)
        
        
        mid_res = torch.matmul(torch.matmul(Q_layernorm, K_layernorm.transpose(2, 3)), V_layernorm)\
            .reshape(batch_size, -1, Channel_num)
        output = layer_norm(mid_res + Q + V)
        
        return output.reshape(batch_size, Channel_num, H, W)

class Transformer(nn.Module):
    def __init__(self):
        super(Transformer, self).__init__()

    def bis(self, input, dim, index):
        # print("bis opetration start")
        views = [input.size(0)] + [1 if i != dim else -1 for i in range(1, len(input.size()))]
        expanse = list(input.size())
        expanse[0] = -1
        expanse[dim] = -1
        # print(views.shape)
        # print(expanse.shape)
        # print(index.shape)
        index = index.view(views).expand(expanse)
        # print(index.shape)
        # print(torch.gather(input, dim, index).shape)
        # breakpoint()
        return torch.gather(input, dim, index)

    def forward(self, V, K, Q):
        # VAB VAB RGB
        # print('Q', Q.shape)  # torch.Size([1, 256, 128, 128])
        # print('K', K.shape)  # torch.Size([1, 256, 128, 128])
        # print('V', V.shape)  # torch.Size([1, 256, 128, 128])

        ### search
        Q_unfold = F.unfold(Q, kernel_size=(3, 3), padding=1)
        K_unfold = F.unfold(K, kernel_size=(3, 3), padding=1)

        # print(Q_unfold.shape) # [1, 2304, 16384])
        # print(K_unfold.shape) # [1, 2304, 16384])

        K_unfold = K_unfold.permute(0, 2, 1)
        # print(K_unfold.shape)

        K_unfold = F.normalize(K_unfold, dim=2)  # [N, Hr*Wr, C*k*k]
        Q_unfold = F.normalize(Q_unfold, dim=1)  # [N, C*k*k, H*W]

        # print(Q_unfold.shape)
        # print(K_unfold.shape)

        R_lv3 = torch.bmm(K_unfold, Q_unfold)  # [N, Hr*Wr, H*W] # torch.Size([1, 16384, 16384])
        # print("Start")
        # print(R_lv3.shape)
        R_lv3_star, R_lv3_star_arg = torch.max(R_lv3, dim=1)  # [N, H*W] # torch.Size([1, 16384])
        # print(R_lv3_star.shape)
        # print(R_lv3_star_arg.shape)
        # breakpoint()

        # print('===================')
        

        ### transfer
        V_unfold = F.unfold(V, kernel_size=(3, 3), padding=1)
        T_lv3_unfold = self.bis(V_unfold, 2, R_lv3_star_arg)

        # print(V_unfold.shape)
        # print(R_lv3_star_arg.shape)
        # print(T_lv3_unfold.shape)
        

        T_lv3 = F.fold(T_lv3_unfold, output_size=Q.size()[-2:], kernel_size=(3, 3), padding=1) / (3. * 3.)
        S = R_lv3_star.view(R_lv3_star.size(0), 1, Q.size(2), Q.size(3))
        
        # print(T_lv3.shape)
        # print(S.shape)
        # breakpoint()
        return S, T_lv3


class FIQENet(nn.Module):# 用于返回增强过程中需要的层的特征
    def __init__(self, args, input_nc=None, output_nc=None):
        nn.Module.__init__(self)
        self.args = args

        # Get padding
        padding = make_paddding(args)

        # Get norm 归一化
        norm_layer, use_bias = make_norm(args)
        if input_nc is None:
            input_nc = self.args.input_nc
        if output_nc is None:
            output_nc = self.args.output_nc

        # Build Head
        head = []
        head_v = []
        head += [padding(3),
                nn.Conv2d(input_nc, self.args.n_filters, kernel_size=7, bias=use_bias),
                norm_layer(self.args.n_filters),
                nn.ReLU(True)]

        head_v += [padding(3),
                  nn.Conv2d(input_nc, self.args.n_filters, kernel_size=7, bias=use_bias),
                  norm_layer(self.args.n_filters),
                  nn.ReLU(True)]

        # Build down-sampling 两次下采样
        downs = []
        downs_v = []
        for i in range(self.args.n_downs):
            mult = 2 ** i
            downs += [padding(1), nn.Conv2d(self.args.n_filters * mult,
                                            self.args.n_filters * mult * 2,
                                            kernel_size=3, stride=2, bias=use_bias),
                      norm_layer(self.args.n_filters * mult * 2),
                      nn.ReLU(True)]
            downs_v += [padding(1), nn.Conv2d(self.args.n_filters * mult,
                                            self.args.n_filters * mult * 2,
                                            kernel_size=3, stride=2, bias=use_bias),
                      norm_layer(self.args.n_filters * mult * 2),
                      nn.ReLU(True)]

        mult = 2 ** self.args.n_downs

        # Build rev-blocks 九次残差连接
        neck = []
        neck_v = []
        self.in_ch = self.args.n_filters * mult * 4
        for i in range(self.args.n_blocks):
            neck += [ResnetBlock(self.args.n_filters * mult, padding=padding,
                                norm_layer=norm_layer, use_bias=use_bias)]
            neck_v += [ResnetBlock(self.args.n_filters * mult, padding=padding,
                                norm_layer=norm_layer, use_bias=use_bias)]

        # Build up-sampling 两次上采样
        ups = []
        ups_v = []
        for i in range(self.args.n_downs):
            mult = 2 ** (self.args.n_downs - i)
            ups += [nn.ConvTranspose2d(self.args.n_filters * mult,
                                      int(self.args.n_filters * mult / 2),
                                      kernel_size=3, stride=2,
                                      padding=1, output_padding=1,
                                      bias=use_bias),
                   norm_layer(int(self.args.n_filters * mult / 2)),
                   nn.ReLU(True)]
            ups_v += [nn.ConvTranspose2d(self.args.n_filters * mult,
                                      int(self.args.n_filters * mult / 2),
                                      kernel_size=3, stride=2,
                                      padding=1, output_padding=1,
                                      bias=use_bias),
                   norm_layer(int(self.args.n_filters * mult / 2)),
                   nn.ReLU(True)]

        importance_ups = []
        importance_ups_v = []
        for i in range(self.args.n_downs):
            mult = 2 ** (self.args.n_downs - i)
            importance_ups += [nn.ConvTranspose2d(self.args.n_filters * mult,
                                      int(self.args.n_filters * mult / 2),
                                      kernel_size=3, stride=2,
                                      padding=1, output_padding=1,
                                      bias=use_bias),
                   norm_layer(int(self.args.n_filters * mult / 2)),
                   nn.ReLU(True)]
            importance_ups_v += [nn.ConvTranspose2d(self.args.n_filters * mult,
                                      int(self.args.n_filters * mult / 2),
                                      kernel_size=3, stride=2,
                                      padding=1, output_padding=1,
                                      bias=use_bias),
                   norm_layer(int(self.args.n_filters * mult / 2)),
                   nn.ReLU(True)]

        # Build tail
        ups += [padding(3)]
        ups += [nn.Conv2d(self.args.n_filters, output_nc, kernel_size=7, padding=0)]
        ups += [nn.Tanh()]
        ups_v += [padding(3)]
        ups_v += [nn.Conv2d(self.args.n_filters, output_nc, kernel_size=7, padding=0)]
        ups_v += [nn.Tanh()]

        #Build importance tail
        importance_ups += [padding(3)]
        importance_ups += [nn.Conv2d(self.args.n_filters, output_nc, kernel_size=7, padding=0)]
        importance_ups_v += [padding(3)]
        importance_ups_v += [nn.Conv2d(self.args.n_filters, output_nc, kernel_size=7, padding=0)]
        
        # Make model
        self.head = nn.Sequential(*head)
        self.downs = nn.Sequential(*downs)
        self.neck = nn.Sequential(*neck)

        self.ups = nn.Sequential(*ups)
        self.importance_ups = nn.Sequential(*importance_ups)

        self.head_v = nn.Sequential(*head_v)
        self.downs_v = nn.Sequential(*downs_v)
        self.neck_v = nn.Sequential(*neck_v)

        self.ups_v = nn.Sequential(*ups_v)
        self.importance_ups_v = nn.Sequential(*importance_ups_v)

        self.mst = MST()

        # T2net
        self.conv_head, self.conv_down = nn.Conv2d(64 * 2, 64, kernel_size=1), nn.Conv2d(256 * 2, 256, kernel_size=1)
        conv_neck = [nn.Conv2d(256 * 2, 256, kernel_size=1) for _ in range(len(self.neck))]
        self.conv_neck = nn.Sequential(*conv_neck)
        
        self.transformer_head, self.transformer_down = Transformer(), Transformer()
        transformer_neck = [Transformer() for _ in range(len(self.neck))]
        self.transformer_neck = nn.Sequential(*transformer_neck)

        # sigmoid
        self.sigmoid = nn.Sigmoid()

    def forward(self, RGB_input, V_input=None, need_importance=False, layers=None):
        if layers is None:
            # print("INPUT")
            # print("RGB", RGB_input.shape)
            # print("VAB", V_input.shape)

            RGB = self.head(RGB_input)
            V = self.head_v(V_input)
            # print(torch.isnan(RGB).any())
            # print(torch.isnan(V).any())

            # HEAD部分由于使用T2Net会导致爆显存，因此先不引导
            # S, T = self.transformer_head(V, V, RGB)
            # T=torch.cat([RGB,T],1)
            # T=self.self.conv_head[i](T)
            # RGB=RGB+T*S
            # print("RBG", RGB.shape)
            # print("VAB", V.shape)

            # print("HEAD")
            # print("RGB", RGB.shape)
            # print("VAB", V.shape)
            # MST引导
            RGB = RGB + self.mst(RGB, V)
            # print("GUIDE", self.mst(RGB, V).shape)
            # print("Concat", RGB.shape)

            # print("Down")
            RGB = self.downs(RGB)
            V = self.downs_v(V)
            
            # print("RGB", RGB.shape)
            # print("VAB", V.shape)
            S, T = self.transformer_down(V, V, RGB)
            T = torch.cat([RGB,T],1)
            T = self.conv_down(T)
            RGB = RGB+T*S
            # print("GUIDE",(T*S).shape)
            # print("Concat", RGB.shape)

            # RGB = RGB + self.mst(RGB, V) # MST引导

            # 【sigmoid】为X-ray试探性处理
            # RGB = nn.Sigmoid()(RGB)
            # V = nn.Sigmoid()(V)


            for i in range(len(self.neck)):
                # print("Block", i+1)
                RGB = self.neck[i](RGB)
                V = self.neck_v[i](V)

                # print("RGB", RGB.shape)
                # print("VAB", V.shape)
                # print("Fusion")
                # T2Net
                S, T = self.transformer_neck[i](V, V, RGB)
                # print("RGB", RGB.shape)
                # print("T1", T.shape)
                T = torch.cat([RGB,T],1)
                # print("T2", T.shape)
                T = self.conv_neck[i](T)
                # print("T3", T.shape)
                # breakpoint()
                RGB = RGB+T*S
    
                # print("GUIDE",(T*S).shape)
                # print("Concat", RGB.shape)
                # RGB = RGB + self.mst(RGB, V)

            RGB_output = self.ups(RGB)
            V_output = self.ups_v(V)

            # print("RGB_output",RGB_output.shape)
            # print("V_output", V_output.shape)
            
            if need_importance:
                RGB_importance = self.importance_ups(RGB)
                V_importance = self.importance_ups_v(V)
                return RGB_output, V_output, RGB_importance, V_importance
            else:
                return RGB_output, V_output
        else:
            return self.forward_features(RGB_input, layers)# 返回增强过程中需要的层的特征 这里layers为[1,5,9,11,15,18,20]
        
    def forward_features(self, RGB_input, layers):# 返回增强过程中需要的层的特征 这里layers为[1,5,9,11,15,18,20]
        feat = RGB_input
        feats = []# 存放需要的每一层的特征
        layer_id = 0
        for layer in self.head:
            feat = layer(feat)
            if layer_id in layers:
                feats.append(feat)
            layer_id += 1
        for layer in self.downs:
            feat = layer(feat)
            if layer_id in layers:
                feats.append(feat)
            layer_id += 1
        for layer in self.neck:
            feat = layer(feat)
            if layer_id in layers:
                feats.append(feat)
            layer_id += 1
        return feats, feat

class Discriminator(nn.Module):
    def __init__(self, in_channel=3, feat_channel=64, n_layers=6):
        super(Discriminator, self).__init__()

        # Get norm
        norm_layer = nn.InstanceNorm2d
        use_bias = True
        
        input_nc = in_channel

        # Down-sampling
        model = [nn.Conv2d(input_nc, feat_channel,
                           kernel_size=4, stride=2, padding=1, bias=use_bias),
                 nn.LeakyReLU(0.2, True)]

        mult = 1

        for i in range(1, n_layers):
            last_mult = mult
            mult = 2 ** i
            model += [nn.Conv2d(feat_channel * last_mult,
                                feat_channel * mult,
                                kernel_size=4, stride=2, padding=1, bias=use_bias),
                      norm_layer(feat_channel * mult),
                      nn.LeakyReLU(0.2, True)]

        last_mult = mult
        mult = 2 ** n_layers
        model += [nn.Conv2d(feat_channel * last_mult,
                            feat_channel * mult,
                            kernel_size=4, stride=2, padding=1, bias=use_bias),
                  norm_layer(feat_channel * mult),
                  nn.LeakyReLU(0.2, True)]

        model += [nn.Conv2d(feat_channel * mult,
                            1, kernel_size=4, stride=2, padding=1, bias=use_bias)]
        self.model = nn.Sequential(*model)

    def forward(self, input):
        '''
        鉴别器,输出鉴别的二分类结果
        '''
        mid_res = self.model(input).reshape(input.shape[0], -1)
        return torch.sigmoid(mid_res)# 输出鉴别器的生成结果

def init_weights(net, init_type='normal', init_gain=0.02, debug=False):
    """Initialize network weights.
    Parameters:
        net (network)   -- network to be initialized
        init_type (str) -- the name of an initialization method: normal | xavier | kaiming | orthogonal
        init_gain (float)    -- scaling factor for normal, xavier and orthogonal.
    """
    def init_func(m):  # define the initialization function
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if debug:
                print(classname)
            if init_type == 'normal':
                nn.init.normal_(m.weight.data, 0.0, init_gain)
            elif init_type == 'xavier':
                nn.init.xavier_normal_(m.weight.data, gain=init_gain)
            elif init_type == 'kaiming':
                nn.init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                nn.init.orthogonal_(m.weight.data, gain=init_gain)
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                nn.init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:  # BatchNorm Layer's weight is not a matrix; only normal distribution applies.
            nn.init.normal_(m.weight.data, 1.0, init_gain)
            nn.init.constant_(m.bias.data, 0.0)

    net.apply(init_func)  # apply the initialization function <init_func>


def init_net(net, init_type='normal', init_gain=0.02, debug=False, initialize_weights=True):
    """Initialize a network:
    Parameters:
        net (network)      -- the network to be initialized
        init_type (str)    -- the name of an initialization method: normal | xavier | kaiming | orthogonal
        gain (float)       -- scaling factor for normal, xavier and orthogonal.
    Return an initialized network.
    """
    if initialize_weights:
        init_weights(net, init_type, init_gain=init_gain, debug=debug)
    return net

class Normalize(nn.Module):
    def __init__(self, power=2):
        super(Normalize, self).__init__()
        self.power = power

    def forward(self, x):
        norm = x.pow(self.power).sum(1, keepdim=True).pow(1. / self.power)
        out = x.div(norm + 1e-7)
        return out

class Standardlize(nn.Module):
    def __init__(self):
        super(Standardlize, self).__init__()

    def forward(self, x):
        return x / x.mean()

class PatchSampleF(nn.Module):
    def __init__(self, init_type='xavier', init_gain=0.02, nc=256):
        '''
        # 用于打乱patch,并使用mlp解耦高级语义信息
        '''
        # potential issues: currently, we use the same patch_ids for multiple images in the batch
        super(PatchSampleF, self).__init__()
        self.l2norm = Normalize(2)
        self.standard = Standardlize() # Stable gradient 
        self.nc = nc
        self.mlp_init = False
        self.init_type = init_type
        self.init_gain = init_gain


    def create_mlp(self, feats):
        for mlp_id, feat in enumerate(feats):
            feat = feat.cpu()
            input_nc = feat.shape[1]
            # mlp = nn.Sequential(*[nn.Linear(input_nc, self.nc), nn.ReLU(), nn.Linear(self.nc, self.nc)]).cuda()
            mlp = nn.Sequential(nn.Linear(input_nc, self.nc), nn.ReLU(), nn.Linear(self.nc, self.nc)).cuda()
            setattr(self, 'mlp_%d' % mlp_id, mlp)
        init_net(self, self.init_type, self.init_gain)
        self.mlp_init = True

    def forward(self, feats, num_patches=256, patch_ids=None):
        '''
        如果网络还没有初始化,即self.mlp_init = False,需要先对网络进行初始化
        self.create_mlp用于初始化MLP

        网络初始化后,后续的调用会返回打乱后的patches以及对应的patch_id
        patches经过MLP解耦高级语义信息后输出
        返回的patch_ids用于帮助后续对应的图像的特征提取相同位置的patches
        '''
        if not self.mlp_init:
            print('[INFO] Create MLP...')
            self.create_mlp(feats)
            self.mlp_init = True
            return
        return_ids = [] # 返回的patch编号
        return_feats = [] # 返回的patch内容

        for feat_id, feat in enumerate(feats):# 分别处理每一层的patch,这里其实每一个值就代表了一个patch
            B, C, H, W = feat.shape[0], feat.shape[1],  feat.shape[2], feat.shape[3]
            feat_reshape = feat.permute(0, 2, 3, 1).flatten(1, 2) #把特征维度变成 [batch, H*W, C]
            # 用patch_ids对patch进行打乱并随机抽取的操作
            if patch_ids is not None:
                patch_id = patch_ids[feat_id][0].reshape(-1)
            else: # 对patch进行打乱操作,并对应好对应的编号,否则会乱掉
                patch_id = torch.randperm(feat_reshape.shape[1], device=feats[0].device)#生成[0, w*h]随机的编号,用于打乱patch
                patch_id = patch_id[:int(min(num_patches, patch_id.shape[0]))]  #选择前min(num_patches, patch_id.shape[0])个patches
            x_sample = feat_reshape[:, patch_id, :].flatten(0, 1)  # 据生成的随机编号patch_id来打乱patch
            # 利用MLP解耦高级语义信息
            mlp = getattr(self, 'mlp_%d' % feat_id)
            x_sample = mlp(x_sample.to(mlp[0].weight.device))
            return_ids.append(torch.cat([patch_id.reshape(1, -1),patch_id.reshape(1, -1),\
            patch_id.reshape(1, -1),patch_id.reshape(1, -1)]))# 将打乱的顺序也同时返回
            
            x_sample = self.l2norm(x_sample)
            x_sample = x_sample.reshape(B, int(min(num_patches, patch_id.shape[0])), -1)

            return_feats.append(x_sample)

        return return_feats, return_ids