import torch
import torch.nn as nn
import math
from torch.autograd import Variable
import numpy as np
import random

def get_real_img(real_img, mean, std):
    for i in range(3):
        real_img[i] = real_img[i]*std[i] + mean[i]
    # img = ((real_img.cpu().numpy())*255.0).astype(np.uint8)
    img = real_img.cpu().numpy()
    img[img > 1.0] = 1
    img[img < 0.0] = 0
    img = (img*255.0).astype(np.uint8)

    img = img.transpose(1, 2, 0)[..., ::-1]
    return img

def get_mask_img(pre_mask):
    img = pre_mask.cpu().numpy()
    img = img.transpose(1, 2, 0)[..., ::-1]
    img[img >= 0.5] = 1
    img[img <= 0.5] = 0
    img = img.astype(np.uint8)
    img = img*255
    return img

def get_lesion_img(lesion_mask):
    img = lesion_mask.cpu().numpy()
    img = img.transpose(1, 2, 0)[..., ::-1]
    img = img.astype(np.uint8)
    img = img*255
    return img

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def weight_init(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.constant_(m.weight, 1)
        nn.init.constant_(m.bias, 0)



class Positonal_Encoding(nn.Module):
    def __init__(self, d_model, max_len=20000):
        super(Positonal_Encoding, self).__init__()

        position_encoding = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (math.log(10000.0) / d_model))
        position_encoding[:, 0::2] = torch.sin(position * div_term)
        position_encoding[:, 1::2] = torch.cos(position * div_term)
        position_encoding = position_encoding.unsqueeze(0)
        self.register_buffer('position_encoding', position_encoding) 
    
    def forward(self, img_feature):
        output = img_feature + Variable(self.position_encoding[:, :img_feature.shape[1]], requires_grad=False)
        return output
    


class UpSampeBlock(nn.Module):
    def __init__(self, in_channels, out_channels, scale):
        super(UpSampeBlock, self).__init__()
        self.scale = scale
        self.up = nn.functional.interpolate
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.relu2 = nn.ReLU(inplace=True)

        # init weights
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, feature_map):
        mid_res = self.up(feature_map, scale_factor=self.scale, mode='bilinear', align_corners=False)
        output = self.relu2(self.bn2(self.conv(mid_res)))
        return output

def set_requires_grad(nets, requires_grad=False):
    """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
    Parameters:
        nets (network list)   -- a list of networks
        requires_grad (bool)  -- whether the networks require gradients or not
    """
    if not isinstance(nets, list):
        nets = [nets]
    for net in nets:
        if net is not None:
            for param in net.parameters():
                param.requires_grad = requires_grad

def make_paddding(args):
    # Set padding
    if args.padding == 'zero':
        padding = nn.ZeroPad2d
    elif args.padding == 'reflect':
        padding = nn.ReflectionPad2d
    elif args.padding == 'replication':
        padding = nn.ReplicationPad2d
    else:
        raise NotImplementedError
    return padding

def make_norm(args):
    if args.norm == 'in' \
            or args.norm.lower() == 'instancenorm':
        use_bias = True
        norm_layer = nn.InstanceNorm2d
    elif args.norm == 'bn' \
            or args.norm.lower() == 'batchnorm':
        use_bias = False
        norm_layer = nn.BatchNorm2d
    elif args.norm == 'sync_bn' \
            or args.norm.lower() == 'groupnorm':
        use_bias = False
        norm_layer = nn.SyncBatchNorm
    elif args.norm == 'gn' \
            or args.norm.lower() == 'groupnorm':
        raise NotImplementedError()  # TODO
    else:
        raise NotImplementedError()
    return norm_layer, use_bias

class ResnetBlock(nn.Module):
    """Define a Resnet block"""

    def __init__(self, dim, padding, norm_layer, use_bias, use_dropout=False):
        """Initialize the Resnet block
        A resnet block is a conv block with skip connections
        We construct a conv block with build_conv_block function,
        and implement skip connections in <forward> function.
        Original Resnet paper: https://arxiv.org/pdf/1512.03385.pdf
        """
        super(ResnetBlock, self).__init__()
        self.conv_block = self.build_conv_block(dim, padding, norm_layer, use_dropout, use_bias)

    def build_conv_block(self, dim, padding, norm_layer, use_dropout, use_bias):
        """Construct a convolutional block.
        Parameters:
            dim (int)           -- the number of channels in the conv layer.
            padding (nn.Padding)  -- the instance of padding layer: reflect | replicate | zero
            norm_layer          -- normalization layer
            use_dropout (bool)  -- if use dropout layers.
            use_bias (bool)     -- if the conv layer uses bias or not
        Returns a conv block (with a conv layer, a normalization layer, and a non-linearity layer (ReLU))
        """
        conv_block = []

        conv_block += [padding(1)]

        conv_block += [nn.Conv2d(dim, dim, kernel_size=3, bias=use_bias), norm_layer(dim), nn.ReLU(True)]
        if use_dropout:
            conv_block += [nn.Dropout(0.5)]

        conv_block += [padding(1)]
        conv_block += [nn.Conv2d(dim, dim, kernel_size=3, bias=use_bias), norm_layer(dim)]

        return nn.Sequential(*conv_block)

    def forward(self, x):
        """Forward function (with skip connections)"""
        out = x + self.conv_block(x)  # add skip connections
        return out