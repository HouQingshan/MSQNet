import torch
import torch.nn as nn
import torchvision
from torchvision.models import resnet50
from model.utils import Positonal_Encoding
from model.utils import UpSampeBlock

class MIT(nn.Module):
    def __init__(self):
        super(MIT, self).__init__()
        # self.pe = None
        # self.layer_norm = None

    def forward(self, feature_classify, feature_segmentation):

        batch_size = feature_classify.shape[0]
        Channel_num = feature_classify.shape[1]
        H = feature_classify.shape[2]
        W = feature_classify.shape[3]
        
        pe = Positonal_Encoding(Channel_num, H*W).cuda()
        layer_norm = nn.LayerNorm([H*W, Channel_num]).cuda()
        
        classify_feature1 = pe(feature_classify.reshape(batch_size, -1, Channel_num))
        classify_feature2 = pe(feature_classify.reshape(batch_size, -1, Channel_num))
        
        segmentation_feature1 = pe(feature_segmentation.reshape(batch_size, -1, Channel_num))
        segmentation_feature2 = pe(feature_segmentation.reshape(batch_size, -1, Channel_num))
        
        classify_feature1_norm = layer_norm(classify_feature1)\
            .reshape(batch_size, Channel_num, H, W)
        classify_feature2_norm = layer_norm(classify_feature2)\
            .reshape(batch_size, Channel_num, H, W)
        
        segmentation_feature1_norm = layer_norm(segmentation_feature1)\
            .reshape(batch_size, Channel_num, H, W)
        segmentation_feature2_norm = layer_norm(segmentation_feature2)\
            .reshape(batch_size, Channel_num, H, W)
        
        fuse_feature = torch.matmul(classify_feature2_norm, segmentation_feature1_norm.transpose(2, 3))
        
        fuse_feature1 = torch.matmul(fuse_feature, classify_feature1_norm)\
            .reshape(batch_size, -1, Channel_num)
        fuse_feature2 = torch.matmul(fuse_feature, segmentation_feature2_norm)\
            .reshape(batch_size, -1, Channel_num)
        
        output_classify = layer_norm(fuse_feature1 + classify_feature1 + segmentation_feature1)\
            .reshape(batch_size, Channel_num, H, W)
        output_segmentation = layer_norm(fuse_feature2 + classify_feature2 + segmentation_feature2)\
            .reshape(batch_size, Channel_num, H, W)
        
        return output_classify, output_segmentation

class MCLNet(nn.Module):
    def __init__(self):
        super(MCLNet, self).__init__()
        Classify_model = torchvision.models.resnet50(pretrained='pretrained')
        Segmentation_model = torchvision.models.resnet50(pretrained='pretrained')
        for module_name in [
            "conv1",
            "bn1",
            "relu",
            "maxpool",
            "layer1",
            "layer2",
            "layer3",
            "layer4",
            "avgpool",
            "fc",
        ]:
            self.add_module(module_name+'_Clas', getattr(Classify_model, module_name))
            self.add_module(module_name+'_Seg', getattr(Segmentation_model, module_name))
        
        self.mit = MIT()
        
        self.up1 = UpSampeBlock(2048, 1024, 2)
        self.up2 = UpSampeBlock(1024, 512, 2)
        self.up3 = UpSampeBlock(512, 256, 2)
        self.up4 = UpSampeBlock(256, 64, 1)
        self.up5 = UpSampeBlock(64, 3, 4)
        
        self.GAP = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(in_features=2048, out_features=4)

    def forward(self, img):
        '''
        病灶分割以及分类网络
        输入为质量增强后的图像
        输出分割和分类的结果
        '''
        #encoder interaction
        #layer1
        downsample1_clas = self.maxpool_Clas(self.relu_Clas(self.bn1_Clas(self.conv1_Clas(img))))
        downsample1_seg = self.maxpool_Seg(self.relu_Seg(self.bn1_Seg(self.conv1_Seg(img))))
        MIT1_clas, MIT1_seg = self.mit(downsample1_clas, downsample1_seg)
        downsample1_clas = downsample1_clas + MIT1_clas
        downsample1_seg = downsample1_seg + MIT1_seg
        
        #layer2
        downsample2_clas = self.layer1_Clas(downsample1_clas)
        downsample2_seg = self.layer1_Seg(downsample1_seg)
        MIT2_clas, MIT2_seg = self.mit(downsample2_clas, downsample2_seg)
        downsample2_clas = downsample2_clas + MIT2_clas
        downsample2_seg = downsample2_seg + MIT2_seg
        
        #layer3
        downsample3_clas = self.layer2_Clas(downsample2_clas)
        downsample3_seg = self.layer2_Seg(downsample2_seg)
        MIT3_clas, MIT3_seg = self.mit(downsample3_clas, downsample3_seg)
        downsample3_clas = downsample3_clas + MIT3_clas
        downsample3_seg = downsample3_seg + MIT3_seg
        
        #layer4
        downsample4_clas = self.layer3_Clas(downsample3_clas)
        downsample4_seg = self.layer3_Seg(downsample3_seg)
        MIT4_clas, MIT4_seg = self.mit(downsample4_clas, downsample4_seg)
        downsample4_seg = downsample4_seg + MIT4_seg
        
        #layer5
        downsample5_seg = self.layer4_Seg(downsample4_seg)



        #decoder
        upsample1_seg = self.up1(downsample5_seg)
        downsample4_clas = downsample4_clas + torch.matmul(MIT4_clas, upsample1_seg.transpose(2, 3))
        downsample5_clas = self.layer4_Clas(downsample4_clas)
        output_clas = self.fc(self.GAP(downsample5_clas).reshape(downsample5_clas.shape[0], -1))
        

        upsample2_seg = self.up2(upsample1_seg)
        upsample3_seg = self.up3(upsample2_seg)
        upsample4_seg = self.up4(upsample3_seg)
        output_seg = self.up5(upsample4_seg)
        
        return output_clas, output_seg