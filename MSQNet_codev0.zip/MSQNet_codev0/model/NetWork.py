import torch
import torch.nn as nn
from model.FIQE import FIQENet
from model.MCL import MCLNet

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.FIQENet = FIQENet()
        self.MCLNet = MCLNet()
        
    def forward(self, RGB_img, VAB_img):
        RGB_en, VAB_en = self.FIQENet(RGB_img, VAB_img)
        classify_res, seg_res = self.MCLNet(RGB_en)
        
        return RGB_en, VAB_en, classify_res, seg_res