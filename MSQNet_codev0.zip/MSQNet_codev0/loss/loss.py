import torch
import torch.nn as nn 
import torch.nn.functional as F

class DiceLoss(nn.Module):
    def __init__(self, weight=None, size_average=True):
        super(DiceLoss, self).__init__()

    def forward(self, inputs, targets, smooth=1):
        
        N = inputs.shape[0]
        inputs = torch.sigmoid(inputs)

        inputs_flat = inputs.view(N, -1)
        targets_flat = targets.view(N, -1)

        intersection = inputs_flat * targets_flat 
        dice_eff = (2 * intersection.sum(1) + smooth) / (inputs_flat.sum(1) + targets_flat.sum(1) + smooth)

        return 1 - dice_eff.sum()/N

def NCE_loss(l_pos, l_neg):
    out = torch.cat((l_pos, l_neg), dim=2)# [bacth, patches, patches+1]
    out_sum = torch.sum(out, dim=2)# [bacth, patches]
    loss = -torch.log(l_pos.reshape(l_pos.shape[0], -1)/out_sum)

    return loss.mean(1)/20.0 #防止loss过大抑制其他loss的传播


class ICCLoss(nn.Module):
    def __init__(self, args):
        super(ICCLoss, self).__init__()
        self.args = args
        self.cross_entropy_loss = torch.nn.CrossEntropyLoss(reduction='none')
        self.mask_dtype = torch.bool# if version.parse(torch.__version__) < version.parse('1.2.0') else torch.bool

    def forward(self, feat_q, feat_k):
        '''
        计算nce_loss, 即对比学习中的loss, 利用正负样本对计算loss
        '''
        # print(feat_q.shape) # [4, patches, C]
        batchSize = feat_q.shape[0] # 获得batch_size
        num_patches = feat_q.shape[1]
        dim = feat_q.shape[2]# 获得通道数C,即特征维度
        # feat_k = feat_k.detach()

        # pos logit
        # Calculate the bmm of the f_q and f_k

        l_pos = torch.bmm(feat_q.reshape(batchSize*num_patches, 1, dim), feat_k.reshape(batchSize*num_patches, dim, 1))# [batch, num_patches 1, 1]
        l_pos = l_pos.reshape(batchSize, num_patches, 1)#结果大小变为[batch, num_patches]


        # 将两个特征相乘 维度变成 [batch, num_patches, num_patches],
        # 这里需要重点提一下,正负样本的问题,对于第一个特征的一个值,第二个特征相同位置的值看作第一个特征的该位置的正样本,其他均看作负样本
        l_neg_curbatch = torch.bmm(feat_q, feat_k.transpose(2, 1)) # [batch, num_patches, num_patches],

        diagonal = torch.eye(num_patches, device=feat_q.device, dtype=self.mask_dtype)[None, :, :]
        l_neg = l_neg_curbatch.masked_fill_(diagonal, -10.0)  # Replace the corresponding patch with negative value
        
        # 然后用交叉熵损失算出nce_Loss的值
        # out = torch.cat((l_pos, l_neg), dim=2)/self.args.nce_T# [batch, num_patches, num_patches + 1]
        # l_neg = l_neg_curbatch.view(-1, num_patches*num_patches)#[batch, patches*patches]
        # out = torch.cat((l_pos, l_neg), dim=1)  / self.args.nce_T #[batch, 1+patches*patches]
        # loss = self.cross_entropy_loss(out, torch.zeros(out.size(0), dtype=torch.long,
        #                                                 device=feat_q.device))
        loss = NCE_loss(torch.exp(l_pos/self.args.nce_T), torch.exp(l_neg/self.args.nce_T))

        # print(loss)
        return loss

class GANLoss(nn.Module):
    def __init__(self):
        super(GANLoss, self).__init__()
        self.real_loss = lambda x: F.mse_loss(x, torch.ones_like(x))
        self.fake_loss = lambda x: F.mse_loss(x, torch.zeros_like(x))

    def update_g(self, good_dis, fake_good):#计算gan_loss
        '''
        利用增强质量后的图像计算gan_loss,用于训练图像质量增强模型
        '''
        fake_good_logits = good_dis(fake_good)# 得到鉴别器的结果
        # print(f'update_g:{fake_good_logits}')
        # print(fake_good_logits)
        good_loss = self.real_loss(fake_good_logits)# 计算对抗生成网络损失
        return good_loss

    def update_d(self, good_dis, real_good, fake_good):# 计算dis_loss
        '''
        利用真实高质量图像和增强质量后的图像计算dis_loss,用于训练鉴别器
        '''
        # Train dis_good
        real_good_logits = good_dis(real_good)# 鉴别器鉴别真实的高质量图像的结果
        fake_good_logits = good_dis(fake_good.detach())# 鉴别器鉴别真实的低质量图像增强后的图像的结果
        # print(f'update_d:{real_good_logits} and {fake_good_logits}')
        real_good_loss = self.real_loss(real_good_logits)# 鉴别器鉴别真实的高质量图像的结果的损失
        fake_good_loss = self.fake_loss(fake_good_logits)# 鉴别器鉴别低质量图像增强后的图像的结果的损失
        good_dis_loss = (real_good_loss + fake_good_loss) / 2 # 求两个损失的平均值
        return good_dis_loss

def nce_loss(args, f_model, feat_q, feat_k):
    '''
    先分别获得feat_q和feat_k中间特征的对应打乱后随机抽取的patches,分别为feat_k_pool和feat_q_pool
    然后用计算这些patches之间的nce_loss
    '''
    feat_k_pool, sample_ids = f_model(feat_k, args.n_patches)
    feat_q_pool, _ = f_model(feat_q, args.n_patches, sample_ids)
    nce_loss = 0.
    ICC = ICCLoss(args)

    for f_q, f_k in zip(feat_q_pool, feat_k_pool):
        nce_loss += ICC(f_q, f_k).mean()
    return nce_loss

class ISLoss(nn.Module):
    # Importance supervised loss (IS-loss)
    def __init__(self,  reduction='mean'):
        super(ISLoss, self).__init__()
        self.reduction = reduction

    def forward(self, source, target, weight):
        loss = self.calculate_loss(source, target, F.leaky_relu(weight))
        return loss

    def calculate_loss(self, pred, target, log_weight):# 计算ISloss的过程
        #  pred, target, log_weight分别为  低质量图像增强后的图像、真实的高质量图像 以及 重要性引导图
        weight = 1/torch.exp(log_weight)
        mse = F.mse_loss(pred, target)
        import math
        if math.isnan(mse.item()):
            print('prediction:', pred.min(), pred.max())
            print('target:', target.min(), target.max())
            print('error')
            return 1e-9
            # breakpoint()
        # print(f'mse: {mse}')
        if self.reduction == 'mean':
            return torch.mean(weight)*mse + torch.mean(log_weight)
        return weight * mse + log_weight

# import torch
# import torch.nn as nn 
# import torch.nn.functional as F

# class DiceLoss(nn.Module):
#     def __init__(self, weight=None, size_average=True):
#         super(DiceLoss, self).__init__()

#     def forward(self, inputs, targets, smooth=1):
        
#         N = inputs.shape[0]
#         inputs = torch.sigmoid(inputs)

#         inputs_flat = inputs.view(N, -1)
#         targets_flat = targets.view(N, -1)

#         intersection = inputs_flat * targets_flat 
#         dice_eff = (2 * intersection.sum(1) + smooth) / (inputs_flat.sum(1) + targets_flat.sum(1) + smooth)

#         return 1 - dice_eff.sum()/N

# def NCE_loss(l_pos, l_neg):
#     out = torch.cat((l_pos, l_neg), dim=2)# [bacth, patches, patches+1]
#     out_sum = torch.sum(out, dim=2)# [bacth, patches]
#     loss = -torch.log(l_pos.reshape(l_pos.shape[0], -1)/out_sum)

#     return loss.mean(1)/20.0 #防止loss过大抑制其他loss的传播


# class ICCLoss(nn.Module):
#     def __init__(self, args):
#         super(ICCLoss, self).__init__()
#         self.args = args
#         self.cross_entropy_loss = torch.nn.CrossEntropyLoss(reduction='none')
#         self.mask_dtype = torch.bool# if version.parse(torch.__version__) < version.parse('1.2.0') else torch.bool

#     def forward(self, feat_q, feat_k):
#         '''
#         计算nce_loss, 即对比学习中的loss, 利用正负样本对计算loss
#         '''
#         # print(feat_q.shape) # [4, patches, C]
#         batchSize = feat_q.shape[0] # 获得batch_size
#         num_patches = feat_q.shape[1]
#         dim = feat_q.shape[2]# 获得通道数C,即特征维度
#         # feat_k = feat_k.detach()

#         # pos logit
#         # Calculate the bmm of the f_q and f_k

#         l_pos = torch.bmm(feat_q.reshape(batchSize*num_patches, 1, dim), feat_k.reshape(batchSize*num_patches, dim, 1))# [batch, num_patches 1, 1]
#         l_pos = l_pos.reshape(batchSize, num_patches, 1)#结果大小变为[batch, num_patches]


#         # 将两个特征相乘 维度变成 [batch, num_patches, num_patches],
#         # 这里需要重点提一下,正负样本的问题,对于第一个特征的一个值,第二个特征相同位置的值看作第一个特征的该位置的正样本,其他均看作负样本
#         l_neg_curbatch = torch.bmm(feat_q, feat_k.transpose(2, 1)) # [batch, num_patches, num_patches],

#         diagonal = torch.eye(num_patches, device=feat_q.device, dtype=self.mask_dtype)[None, :, :]
#         l_neg = l_neg_curbatch.masked_fill_(diagonal, -10.0)  # Replace the corresponding patch with negative value
        
#         # 然后用交叉熵损失算出nce_Loss的值
#         # out = torch.cat((l_pos, l_neg), dim=2)/self.args.nce_T# [batch, num_patches, num_patches + 1]
#         # l_neg = l_neg_curbatch.view(-1, num_patches*num_patches)#[batch, patches*patches]
#         # out = torch.cat((l_pos, l_neg), dim=1)  / self.args.nce_T #[batch, 1+patches*patches]
#         # loss = self.cross_entropy_loss(out, torch.zeros(out.size(0), dtype=torch.long,
#         #                                                 device=feat_q.device))
#         loss = NCE_loss(torch.exp(l_pos/self.args.nce_T), torch.exp(l_neg/self.args.nce_T))

#         # print(loss)
#         return loss

# class GANLoss(nn.Module):
#     def __init__(self):
#         super(GANLoss, self).__init__()
#         self.real_loss = lambda x: F.mse_loss(x, torch.ones_like(x))
#         self.fake_loss = lambda x: F.mse_loss(x, torch.zeros_like(x))

#     def update_g(self, good_dis, fake_good):#计算gan_loss
#         '''
#         利用增强质量后的图像计算gan_loss,用于训练图像质量增强模型
#         '''
#         fake_good_logits = good_dis(fake_good)# 得到鉴别器的结果
#         print(f'update_g:{fake_good_logits}')
#         # print(fake_good_logits)
#         good_loss = self.real_loss(fake_good_logits)# 计算对抗生成网络损失
#         return good_loss

#     def update_d(self, good_dis, real_good, fake_good):# 计算dis_loss
#         '''
#         利用真实高质量图像和增强质量后的图像计算dis_loss,用于训练鉴别器
#         '''
#         # Train dis_good
#         real_good_logits = good_dis(real_good)# 鉴别器鉴别真实的高质量图像的结果
#         fake_good_logits = good_dis(fake_good.detach())# 鉴别器鉴别真实的低质量图像增强后的图像的结果
#         print(f'update_d:{real_good_logits} and {fake_good_logits}')
#         real_good_loss = self.real_loss(real_good_logits)# 鉴别器鉴别真实的高质量图像的结果的损失
#         fake_good_loss = self.fake_loss(fake_good_logits)# 鉴别器鉴别低质量图像增强后的图像的结果的损失
#         good_dis_loss = (real_good_loss + fake_good_loss) / 2 # 求两个损失的平均值
#         return good_dis_loss


# def nce_loss(args, f_model, feat_q, feat_k):
#     '''
#     先分别获得feat_q和feat_k中间特征的对应打乱后随机抽取的patches,分别为feat_k_pool和feat_q_pool
#     然后用计算这些patches之间的nce_loss
#     '''
#     feat_k_pool, sample_ids = f_model(feat_k, args.n_patches)
#     feat_q_pool, _ = f_model(feat_q, args.n_patches, sample_ids)
#     nce_loss = 0.
#     ICC = ICCLoss(args)
#     for f_q, f_k in zip(feat_q_pool, feat_k_pool):
#         nce_loss += ICC(f_q, f_k).mean()
#     return nce_loss
