import torch
import torch.nn as nn
import torch.optim as optim
import argparse
import os
from model.utils import setup_seed, weight_init, get_real_img, set_requires_grad, get_mask_img, get_lesion_img
from model.FIQE import FIQENet, Discriminator, PatchSampleF
from model.MCL import MCLNet
from dataprocess.dataset import MyDataset
from torch.utils.data import DataLoader
from loss.loss import DiceLoss
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
from sklearn.metrics import roc_auc_score
import cv2
cv2.setNumThreads(1)
from loss.loss import nce_loss, GANLoss, ISLoss
import csv
import gc
import sys
import kornia
import torch.distributed as dist
from tqdm import tqdm
from skimage.metrics import structural_similarity as get_ssim
sys.setrecursionlimit(10000)


def get_arguments():
    parser = argparse.ArgumentParser()
    # data
    task = 'EyeQ'  # ['EyeQ', 'Endoscope', 'Heart CT', 'ISIC', 'Nerve Tortuosity', 'X-ray']

    if task == 'EyeQ':
        parser.add_argument('--train_csv_path', default='./txts/train_FIQE.csv', type=str)
        parser.add_argument('--val_csv_path', default='./txts/val_FIQE.csv', type=str)
        parser.add_argument('--test_csv_path', default='./txts/test_FIQE.csv', type=str)
        parser.add_argument('--gt_image_path', default='../dataL/gt_image/', type=str)
        parser.add_argument('--de_image_path', default='../dataL/de_image/', type=str)
        parser.add_argument('--image_mask', default='../dataL/image_mask/', type=str)
    else:
        parser.add_argument('--train_csv_path', default='./data/{}/low_images.csv'.format(task), type=str)
        parser.add_argument('--val_csv_path', default='./data/{}/low_images.csv'.format(task), type=str)
        parser.add_argument('--test_csv_path', default='./data/{}/low_images.csv'.format(task), type=str)
        parser.add_argument('--gt_image_path', default='./data/{}/low/'.format(task), type=str)
        parser.add_argument('--de_image_path', default='./data/{}/degraded_low/'.format(task), type=str)
        parser.add_argument('--image_mask', default='None', type=str)
        
    # 模型ckpt及log保存路径
    parser.add_argument('--FIQE_ckpt_path', type=str, help='path to save FIQE model',default='./ckpt_path/{}/checkpoints'.format(task))
    parser.add_argument('--FIQE_log_path', type=str, help='path to save FIQE model',default='./ckpt_path/{}/'.format(task))


    # 测试模型路径
    # 【high】
    # eyeQ
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/EyeQ/checkpoints/FIQE_model_epoch_249_ave_psnr_30.741394731420208.pth'
    # Endoscope
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/Endoscope/checkpoints/FIQE_model_epoch_240_ave_psnr_37.741876493622215.pth'
    # Heart CT
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/Heart CT/checkpoints/FIQE_model_epoch_290_ave_psnr_40.498089082127144.pth'
    # Nerve
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/Nerve Tortuosity/checkpoints/FIQE_model_epoch_142_ave_psnr_24.788361960550677.pth'
    # ISIC
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/ISIC/checkpoints/FIQE_model_epoch_199_ave_psnr_30.588482206095886.pth'
    # X-ray
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/X-ray/checkpoints/FIQE_model_epoch_260_ave_psnr_34.773248925408026.pth'

    # 【Low】
    # Endoscope
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/Endoscope/checkpoints/FIQE_model_epoch_170_ave_psnr_35.35071465082301.pth'
    # Heart CT
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/Heart CT/checkpoints/FIQE_model_epoch_152_ave_psnr_42.81794018653834.pth'
    # Nerve
    # ckpt = '/home/cent/WYQ/FIQE/ckpt_path/Nerve Tortuosity/checkpoints/FIQE_model_epoch_299_ave_psnr_26.215680295996737.pth'
    # X-ray
    ckpt = '/home/cent/WYQ/FIQE/ckpt_path/X-ray/checkpoints/FIQE_model_epoch_156_ave_psnr_29.941581303030063.pth'
    parser.add_argument('--FIQE_path', type=str, help='path to load FIQE model', default=ckpt)  
    # parser.add_argument('--MCL_path', type=str, help='path to load MCL model')

    parser.add_argument('--batch_size', default=1, type=int)
    parser.add_argument('--epochs', default=300, type=int)

    parser.add_argument('--optimizer', default='adam', type=str, choices=['sgd', 'adam'])
    parser.add_argument('--beta1', type=float, default=0.5, help='beta1 for adam')
    parser.add_argument('--beta2', type=float, default=0.999, help='beta2 for adam')
    parser.add_argument('--weight_decay', type=float, default=0.0001, help='weight decay for optim')
    parser.add_argument('--learning_rate', default=0.0001, type=float, help='initial learning rate')
    parser.add_argument('--lr_decay_step', default=70, type=int, help='where learning rate decays')
    parser.add_argument('--lr_decay_ratio', default=0.1, type=float, help='decay coefficient')

    parser.add_argument('--train', action='store_true', help='turn on train mode')
    parser.add_argument('--gpu_ids', default='3', type=str, help='GPU ids')
    parser.add_argument('--random_seed', default=0, type=int)

    parser.add_argument('--used_model', required=False, type=str, help='the model will be used FIQE|MCL')
    parser.add_argument('--n_patches', type=int, default=256, help='the f_model used')
    parser.add_argument('--nce_T', type=float, default=0.07, help='the temperature weight in nce-loss')

    parser.add_argument('--n_layers', type=int, default=3, help='the number of layers used in discriminator')
    parser.add_argument('--n_downs', type=int, default=2, help='the number of down-samplings used in generator')
    parser.add_argument('--n_filters', type=int, default=64, help='the number of filters used in generator')
    parser.add_argument('--n_blocks', type=int, default=9,
                            help='the number of blocks used in the low-level of generator')
    parser.add_argument('--input_nc', type=int, default=3, help='the number of input channels')
    parser.add_argument('--output_nc', type=int, default=3, help='the number of output channels')
    parser.add_argument('--dis_n_filters', type=int, default=64, help='the number of filters used in discriminator')
    parser.add_argument('--norm', type=str, default='in', help='Norm layer. Usable: in | bn ')
    parser.add_argument('--padding', type=str, default='reflect', help='padding layer. '
                                                                        'Usable: reflect | replication | zero ')
    #parser.add_argument('--FIQE_layers', type=str, default='1,5,9,11,15,18,20', help='the index of FIQE layers')
    return parser.parse_args()

class Mymodel():
    def __init__(self, args):
        self.args = args

    def train_FIQE_epoch(self, epoch, device, dataloader):
        '''
        train FIQE Model
        先通过self.fiqe_model获得增强后的RGB和VAB图像特征
        再分别获得增强图像的中间特征feat_k以及高质量图像的中间特征feat_q

        feat_k和feat_q均是包含8层特征的List,用于计算nce_loss
        并联合nce_loss、gan_loss、rgb_loss以及vab_loss训练更新self.fiqe_model的参数

        最后用dis_loss训练更新鉴别器参数,用作对抗学习
        '''

        # mes_loss = nn.MSELoss()
        is_loss = ISLoss()
        gan_loss = GANLoss() # 对抗生成损失
        # l1_loss = nn.L1Loss()

        # MS_ssim_loss = kornia.losses.MS_SSIMLoss(alpha=0.84)
        # MS_ssim_loss = MS_ssim_loss.to(device)


        self.fiqe_model.train()
        self.dis_model.train()
        print("Start FIQENet training ... ")
        
        _loss = 0

        for gt_image_rgb, de_image_rgb, gt_image_v, de_image_v, image_mask, _ in tqdm(dataloader):
            # print(f'step:{step}')
            gt_image_rgb = gt_image_rgb.to(device)
            de_image_rgb = de_image_rgb.to(device)
            gt_image_v = gt_image_v.to(device)
            de_image_v = de_image_v.to(device)
            

            set_requires_grad(self.dis_model, False)
            RGB_en, V_en, RGB_importance, V_importance = self.fiqe_model(RGB_input=de_image_rgb, V_input=de_image_v, need_importance=True) #获得增强的RGB和VAB图像特征

            if image_mask[0] != 'None':
                image_mask = image_mask.to(device)
                feat_k, _ = self.fiqe_model(RGB_input=RGB_en*image_mask, layers = [1,5,9,11,15,18,20])# 获取增强图像的中间特征
                feat_q, _ = self.fiqe_model(RGB_input=gt_image_rgb*image_mask, layers = [1,5,9,11,15,18,20])# 获取原始图像的中间特征
            else:
                feat_k, _ = self.fiqe_model(RGB_input=RGB_en, layers = [1,5,9,11,15,18,20])# 获取增强图像的中间特征
                feat_q, _ = self.fiqe_model(RGB_input=gt_image_rgb, layers = [1,5,9,11,15,18,20])# 获

            if epoch==0: # initial f_model
                epoch+=1
                self.f_model(feat_k, self.args.n_patches)
                self.f_model.to(device)
                self.f_model = torch.nn.DataParallel(self.f_model, device_ids=self.gpu_ids)
                self.f_model.cuda()
                if self.args.optimizer == 'sgd':
                    self.f_optimizer = optim.SGD(self.f_model.parameters(), lr=self.args.learning_rate, 
                                momentum=0.9, weight_decay=1e-4)
                elif self.args.optimizer == 'adam':
                    self.f_optimizer = optim.Adam(params=self.f_model.parameters(), lr=self.args.learning_rate,
                          betas=(args.beta1, args.beta2),weight_decay=args.weight_decay)
                elif self.args.optimizer == 'adam_belief':
                    self.f_optimizer = AdaBelief(params=self.f_model.parameters(), lr=self.args.learning_rate,
                          betas=(args.beta1, args.beta2),weight_decay=args.weight_decay, print_change_log = False)
                self.f_scheduler = optim.lr_scheduler.StepLR(self.f_optimizer, self.args.lr_decay_step, self.args.lr_decay_ratio)
                self.f_scheduler = optim.lr_scheduler.CosineAnnealingLR(self.f_optimizer, T_max=self.args.epochs)
                self.f_model.train()

            self.fiqe_optimizer.zero_grad()
            self.f_optimizer.zero_grad()
            loss_icc = nce_loss(self.args, self.f_model, feat_q, feat_k)# 对比学习的nce_loss
            loss_rgb = is_loss(RGB_en, gt_image_rgb, RGB_importance)
            # loss_v = is_loss(V_en, gt_image_v, V_importance)
            loss_gan = gan_loss.update_g(self.dis_model, RGB_en)# 对抗生成loss

            # 防止梯度爆炸
            loss_icc = 0 if loss_icc > 10 else loss_icc
            loss_rgb = 0 if loss_rgb > 10 else loss_rgb
            # loss_v = 0 if loss_v > 10 else loss_v
            loss_gan = 0 if loss_gan > 10 else loss_gan


            # loss = 0.3*loss_icc + loss_rgb + loss_v + 0.5*loss_gan
            loss = 0.3*loss_icc + loss_rgb + 0.5*loss_gan

            loss.backward()
            self.fiqe_optimizer.step()
            self.f_optimizer.step()

            set_requires_grad(self.dis_model, True)

            _loss += loss.item()
            # train discriminator
            set_requires_grad(self.fiqe_model, False)
            self.dis_optimizer.zero_grad()
            loss_dis = gan_loss.update_d(self.dis_model, gt_image_rgb, RGB_en)
            loss_dis = 0.0001 if loss_dis > 10 else loss_dis
            loss_dis.backward()
            self.dis_optimizer.step()

            set_requires_grad(self.fiqe_model, True)
            #print(f'loss:{loss.item()}, rgb_loss:{loss_rgb.item()}, v_loss:{loss_v.item()}, nce_loss:{loss_icc.item()}, gan_loss:{loss_gan.item()}, dis_loss:{loss_dis.item()}')

            # #释放loss
            # del loss, loss_dis, loss_icc, loss_gan, loss_rgb, loss_v
            # gc.collect()
            # torch.cuda.empty_cache()


        self.fiqe_scheduler.step()
        self.f_scheduler.step()
        self.dis_scheduler.step()

        return _loss / len(dataloader)

    def valid_FIQE(self, epoch, device, dataloader):

        with torch.no_grad():
            self.fiqe_model.eval()

            psnr_list = []
            ssim_list = []

            flag = 0
            
            for gt_image_rgb, de_image_rgb, gt_image_v, de_image_v, image_mask, image_name in tqdm(dataloader):

                gt_image_rgb = gt_image_rgb.to(device)
                de_image_rgb = de_image_rgb.to(device)
                gt_image_v = gt_image_v.to(device)
                de_image_v = de_image_v.to(device)
                # image_mask = image_mask.to(device)
               
                if image_mask[0] != 'None':
                    image_mask = image_mask.numpy()

                RGB_en, V_en = self.fiqe_model(RGB_input=de_image_rgb, V_input=de_image_v)

                #calculate the metrics
                for i in range(gt_image_rgb.shape[0]):
                    
                    mean_list = [0.5, 0.5, 0.5]
                    std_list = [0.5, 0.5, 0.5]

                    # mean_list = [0.485, 0.456, 0.406]
                    # std_list =  [0.229, 0.224, 0.225]

                    #get rgb img
                    RGB_gt_img = get_real_img(gt_image_rgb[i], mean_list, std_list)
                    RGB_de_img = get_real_img(de_image_rgb[i], mean_list, std_list)
                    RGB_en_img = get_real_img(RGB_en[i], mean_list, std_list)

                    #get V img
                    V_gt_img = get_real_img(gt_image_v[i], mean_list, std_list)
                    V_de_img = get_real_img(de_image_v[i], mean_list, std_list)
                    V_en_img = get_real_img(V_en[i], mean_list, std_list)

                    if image_mask[0] != 'None':
                        image_mask_img = image_mask[i].transpose(1, 2, 0)[..., ::-1]
                        RGB_en_img = RGB_en_img*image_mask_img
                        V_de_img = V_de_img*image_mask_img
                        V_gt_img = V_gt_img*image_mask_img
                        V_en_img = V_en_img*image_mask_img


                    #psnr
                    cur_psnr = psnr(RGB_gt_img, RGB_en_img)
                    #ssim
                    cur_ssim = get_ssim(RGB_gt_img, RGB_en_img, multichannel=True)
                    psnr_list.append(cur_psnr)
                    ssim_list.append(cur_ssim)
                    # print(f'{image_name[i]}:{cur_psnr}')
                    # print(f'{image_name[i]}:{cur_ssim}')
                    # breakpoint()

                    if epoch == 'test' and flag < 500:
                        # pass
                        # 测试逻辑
                        # gt_image_rgb, de_image_rgb, gt_image_v, de_image_v
                        # save de_rgb
                        img_name = os.path.join(self.args.FIQE_log_path, 'test', '{}_de_rgb.png'.format(image_name[i][:-4]))
                        cv2.imwrite(img_name, RGB_de_img)
                        # save de_vab
                        img_name = os.path.join(self.args.FIQE_log_path, 'test', '{}_de_vab.png'.format(image_name[i][:-4]))
                        cv2.imwrite(img_name, V_de_img)
                        # save en_rgb                      
                        img_name = os.path.join(self.args.FIQE_log_path, 'test', '{}_en_rgb.png'.format(image_name[i][:-4]))
                        cv2.imwrite(img_name, RGB_en_img)                        
                        # save en_vab                       
                        img_name = os.path.join(self.args.FIQE_log_path, 'test', '{}_en_vab.png'.format(image_name[i][:-4]))
                        cv2.imwrite(img_name, V_en_img)
                        # save gt_rgb                      
                        img_name = os.path.join(self.args.FIQE_log_path, 'test', '{}_gt_rgb.png'.format(image_name[i][:-4]))
                        cv2.imwrite(img_name, RGB_gt_img)                        
                        # save gt_vab            
                        img_name = os.path.join(self.args.FIQE_log_path, 'test', '{}_gt_vab.png'.format(image_name[i][:-4]))
                        cv2.imwrite(img_name, V_gt_img)                        

                    else:
                        # 验证逻辑
                        if flag < 20:  # 可视化前20张图像
                            #save img
                            line = np.ones((512, 10, 3)) * 32
                            RGB_cat_imgs = np.concatenate([RGB_gt_img, line, RGB_en_img, line, RGB_de_img], axis=1)
                            img_name = os.path.join(self.args.FIQE_log_path, 'images', 'epoch{}_{}'.format(epoch, image_name[i]))
                            cv2.imwrite(img_name, RGB_cat_imgs)
                    
                    flag+=1

        return psnr_list, ssim_list

    def train_FIQE(self):
        '''
        self.fiqe_model = FIQENet() 是用于图像增强的网络
        '''
        # 模型初始化设置
        setup_seed(self.args.random_seed)
        os.environ["CUDA_VISIBLE_DEVICES"] = self.args.gpu_ids
        self.gpu_ids = list(range(torch.cuda.device_count()))

        device = torch.device('cuda')

        self.fiqe_model = FIQENet(self.args) # 用于图像增强的网络
        self.dis_model = Discriminator() # 鉴别器网络
        self.f_model = PatchSampleF() #用于Patch打乱、随机抽取并进行特征提取的网络
 
        self.fiqe_model.apply(weight_init)
        self.dis_model.apply(weight_init)

        self.fiqe_model.to(device)
        self.dis_model.to(device)

        self.fiqe_model = torch.nn.DataParallel(self.fiqe_model, device_ids=self.gpu_ids)
        self.dis_model = torch.nn.DataParallel(self.dis_model, device_ids=self.gpu_ids)

        self.fiqe_model.cuda()
        self.dis_model.cuda()

        if self.args.optimizer == 'sgd':
            self.fiqe_optimizer = optim.SGD(self.fiqe_model.parameters(), lr=self.args.learning_rate, 
                        momentum=0.9, weight_decay=1e-4)
            self.dis_optimizer = optim.SGD(self.dis_model.parameters(), lr=self.args.learning_rate, 
                        momentum=0.9, weight_decay=1e-4)
        else:
            self.fiqe_optimizer = optim.Adam(params=self.fiqe_model.parameters(), lr=self.args.learning_rate,
                          betas=(args.beta1, args.beta2),weight_decay=args.weight_decay)
            self.dis_optimizer = optim.Adam(params=self.dis_model.parameters(), lr=self.args.learning_rate,
                          betas=(args.beta1, args.beta2),weight_decay=args.weight_decay)

        self.fiqe_scheduler = optim.lr_scheduler.CosineAnnealingLR(self.fiqe_optimizer, T_max = self.args.epochs)
        self.dis_scheduler = optim.lr_scheduler.CosineAnnealingLR(self.dis_optimizer, T_max=self.args.epochs)
        
        #dataset and dataloader
        train_dataset = MyDataset(self.args, mode='train')
        val_dataset = MyDataset(self.args, mode='val')
        test_dataset = MyDataset(self.args, mode='test')
        
        train_dataloader = DataLoader(train_dataset, batch_size=self.args.batch_size, 
                                    shuffle=True, num_workers=32, pin_memory=True, persistent_workers=True)

        val_dataloader = DataLoader(val_dataset, batch_size=self.args.batch_size, 
                                    shuffle=False, num_workers=32, pin_memory=True, persistent_workers=True)
        
        test_dataloader = DataLoader(test_dataset, batch_size=self.args.batch_size, 
                                    shuffle=False, num_workers=32, pin_memory=True, persistent_workers=True)

        if self.args.train:# train
            
            best_psnr = 0

            loss_file = os.path.join(self.args.FIQE_log_path)
            if not os.path.exists(loss_file):
                os.makedirs(loss_file)

            os.makedirs(os.path.join(loss_file, 'images'), exist_ok=True)

            for epoch in range(self.args.epochs):

                print('Epoch: {}: '.format(epoch))

                batch_loss = self.train_FIQE_epoch(epoch, device, train_dataloader) # train
                psnr_list, ssim_list = self.valid_FIQE(epoch, device, val_dataloader) # valid

                ave_psnr = sum(psnr_list)/len(psnr_list)

                # 记录每轮的训练log
                with open(os.path.join(loss_file, 'log.txt'), "a") as f:
                    f.write("epoch{}\tloss:{}\tpsnr:{}\n".format(epoch, batch_loss, ave_psnr))
                
                if best_psnr < ave_psnr:

                    best_psnr = ave_psnr
                    
                    if not os.path.exists(self.args.FIQE_ckpt_path):
                        os.mkdir(self.args.FIQE_ckpt_path)

                    if not os.path.exists(self.args.FIQE_log_path):
                        os.mkdir(self.args.FIQE_log_path)
                    model_name = 'FIQE_model_epoch_{}_ave_psnr_{}.pth'\
                        .format(epoch, ave_psnr)

                    saved_dict = {'saved_epoch': epoch,
                                    'model': self.fiqe_model.state_dict(),
                                    'optimizer': self.fiqe_optimizer.state_dict(),
                                    'scheduler': self.fiqe_scheduler.state_dict()}

                    save_dir = os.path.join(self.args.FIQE_ckpt_path, model_name)

                    torch.save(saved_dict, save_dir)
                    print('The epoch model has been saved at {}.'.format(save_dir))
                    print("Loss: {:.3f}, max_psnr: {:.3f}, min_psnr: {:.3f}, ave_psnr: {:.3f}"\
                        .format(batch_loss, np.max(psnr_list), np.min(psnr_list), ave_psnr))
                
                else:
                    print("Loss: {:.3f}, max_psnr: {:.3f}, min_psnr: {:.3f}, ave_psnr: {:.3f}"\
                        .format(batch_loss, np.max(psnr_list), np.min(psnr_list), ave_psnr))

        else: # test
            # first load trained model
            loaded_dict = torch.load(self.args.FIQE_path)
            state_dict = loaded_dict['model']

            self.fiqe_model.load_state_dict(state_dict)

            print('Trained model loaded!')

            psnr_list, ssim_list = self.valid_FIQE("test", device, test_dataloader)

            ave_psnr = sum(psnr_list)/len(psnr_list)
            ave_ssim = sum(ssim_list) /len(ssim_list)

            print("max_psnr: {:.3f}, min_psnr: {:.3f}, ave_psnr: {:.3f}"\
                    .format(np.max(psnr_list), np.min(psnr_list), ave_psnr))
            print("max_ssim: {:.3f}, min_ssim: {:.3f}, ave_ssim: {:.3f}"\
                    .format(np.max(ssim_list), np.min(ssim_list), ave_ssim))

'''
    train_FIQE()中调用train_FIQE_epoch和valid_FIQE分别用于train和valid
'''
if __name__ == "__main__":
    args = get_arguments()
    print(args)
    model = Mymodel(args)
    model.train_FIQE()